Visit project [wiki](https://github.com/broadinstitute/inferCNV/wiki) for InferCNV documentation.
